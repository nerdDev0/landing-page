
let headerTopElem = document.getElementById("headerTop");
window.document.addEventListener('scroll',function(){

if(scrollY>100){
headerTopElem.classList.add("header-scroled");
}else{
    headerTopElem.classList.remove("header-scroled");
}
})